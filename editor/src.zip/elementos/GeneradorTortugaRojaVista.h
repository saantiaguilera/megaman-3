/*
 * TortugaRojaVista.h
 *
 *  Created on: 25/11/2015
 *      Author: matiaskamien
 */

#ifndef EDITOR_SRC_ELEMENTOS_GENERADORTORTUGAROJAVISTA_H_
#define EDITOR_SRC_ELEMENTOS_GENERADORTORTUGAROJAVISTA_H_
#include "GeneradorTortugaVista.h"
#include "../../../Common/src/GeneradorTortugaRoja.h"

class GeneradorTortugaRojaVista : public GeneradorTortugaVista {
public:
	GeneradorTortugaRojaVista();
	virtual ~GeneradorTortugaRojaVista();
};

#endif /* EDITOR_SRC_ELEMENTOS_GENERADORTORTUGAROJAVISTA_H_ */
