/*
 * TortugaVerdeVista.h
 *
 *  Created on: 25/11/2015
 *      Author: matiaskamien
 */

#ifndef EDITOR_SRC_ELEMENTOS_GENERADORTORTUGAVERDEVISTA_H_
#define EDITOR_SRC_ELEMENTOS_GENERADORTORTUGAVERDEVISTA_H_
#include "GeneradorTortugaVista.h"
#include "../../../Common/src/GeneradorTortugaVerde.h"

class GeneradorTortugaVerdeVista : public GeneradorTortugaVista{
public:
	GeneradorTortugaVerdeVista();
	virtual ~GeneradorTortugaVerdeVista();
};

#endif /* EDITOR_SRC_ELEMENTOS_GENERADORTORTUGAVERDEVISTA_H_ */
